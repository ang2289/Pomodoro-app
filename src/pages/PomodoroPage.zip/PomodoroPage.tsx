import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { FocusItem, FocusItemWithCount } from '../types/FocusItem'
import { PomodoroRecord } from '../types/PomodoroRecord'
import { TaskTag, TaskTagWithCount } from '../types/TaskTag'
import { 
  getFocusItemsWithCount, 
  addFocusItem, 
  updateFocusItem, 
  deleteFocusItem, 
  recordFocusItemUsage,
  initializeDefaultFocusItems 
} from '../services/focusItemService'
import { exportPomodoroRecordsToCSV, hasRecordsToExport } from '../services/csvExportService'
import { 
  getTaskTagsWithCount, 
  addTaskTag, 
  updateTaskTag, 
  deleteTaskTag, 
  recordTaskTagUsage,
  initializeDefaultTaskTags,
  getRandomTagColor 
} from '../services/taskTagService'

const PomodoroPage = () => {
  const [workMinutes, setWorkMinutes] = useState(25) // 工作時間（分鐘）
  const [breakMinutes, setBreakMinutes] = useState(5) // 休息時間（分鐘）
  const [timeLeft, setTimeLeft] = useState(25 * 60) // 當前剩餘時間（秒）
  const [isRunning, setIsRunning] = useState(false)
  const [isBreak, setIsBreak] = useState(false)
  const [records, setRecords] = useState<PomodoroRecord[]>([]) // 完成紀錄
  const [searchKeyword, setSearchKeyword] = useState('') // 搜尋關鍵字
  const [startDate, setStartDate] = useState('') // 開始日期
  const [endDate, setEndDate] = useState('') // 結束日期
  const [isSearching, setIsSearching] = useState(false) // 是否正在搜尋
  
  // 搜尋欄位選擇狀態
  const [searchFields, setSearchFields] = useState({
    focusItem: true,    // 專注任務名稱
    description: true,  // 任務內容/描述
    time: true         // 開始或結束時間
  })
  
  // 搜尋建議和歷史狀態
  const [searchHistory, setSearchHistory] = useState<string[]>([]) // 搜尋歷史
  const [showSuggestions, setShowSuggestions] = useState(false) // 是否顯示建議
  const [isSearchInputFocused, setIsSearchInputFocused] = useState(false) // 搜尋框是否聚焦
  
  // 專注項目相關狀態
  const [focusItems, setFocusItems] = useState<FocusItemWithCount[]>([])
  const [selectedFocusItemId, setSelectedFocusItemId] = useState<string>('')
  const [showFocusItemModal, setShowFocusItemModal] = useState(false)
  const [newFocusItemName, setNewFocusItemName] = useState('')
  const [editingFocusItem, setEditingFocusItem] = useState<FocusItem | null>(null)
  const [editingFocusItemName, setEditingFocusItemName] = useState('')
  
  // 記錄編輯相關狀態
  const [editingRecord, setEditingRecord] = useState<PomodoroRecord | null>(null)
  const [editingRecordFocusItemId, setEditingRecordFocusItemId] = useState<string>('')
  const [editingRecordCompletedAt, setEditingRecordCompletedAt] = useState<string>('')
  
  // 連續完成次數統計
  const [consecutiveCount, setConsecutiveCount] = useState(0)
  
  // 標籤相關狀態
  const [taskTags, setTaskTags] = useState<TaskTagWithCount[]>([])
  const [selectedTagId, setSelectedTagId] = useState<string>('')
  const [showTagModal, setShowTagModal] = useState(false)
  const [newTagName, setNewTagName] = useState('')
  const [newTagColor, setNewTagColor] = useState('#2196f3')
  const [editingTag, setEditingTag] = useState<TaskTag | null>(null)
  const [editingTagName, setEditingTagName] = useState('')
  const [editingTagColor, setEditingTagColor] = useState('#2196f3')
  
  // 匯出狀態訊息
  const [exportStatus, setExportStatus] = useState<{
    show: boolean
    type: 'success' | 'warning' | 'error'
    message: string
  }>({
    show: false,
    type: 'success',
    message: ''
  })

  // 從 localStorage 載入紀錄
  useEffect(() => {
    const savedRecords = localStorage.getItem('pomodoro-records')
    if (savedRecords) {
      try {
        setRecords(JSON.parse(savedRecords))
      } catch (error) {
        console.error('載入番茄鐘紀錄失敗:', error)
      }
    }
    
    // 載入連續完成次數
    const savedConsecutiveCount = localStorage.getItem('pomodoro-consecutive-count')
    if (savedConsecutiveCount) {
      try {
        setConsecutiveCount(parseInt(savedConsecutiveCount))
      } catch (error) {
        console.error('載入連續完成次數失敗:', error)
      }
    }
  }, [])

  // 載入專注項目
  useEffect(() => {
    initializeDefaultFocusItems()
    const items = getFocusItemsWithCount()
    setFocusItems(items)
    // 預設選擇第一個項目
    if (items.length > 0 && !selectedFocusItemId) {
      setSelectedFocusItemId(items[0].id)
    }
  }, [])

  // 載入標籤
  useEffect(() => {
    initializeDefaultTaskTags()
    const tags = getTaskTagsWithCount()
    setTaskTags(tags)
    // 預設選擇第一個標籤
    if (tags.length > 0 && !selectedTagId) {
      setSelectedTagId(tags[0].id)
    }
  }, [])

  // 設置搜尋日期預設值為今天
  useEffect(() => {
    const today = getTodayDate()
    setStartDate(today)
    setEndDate(today)
  }, [])

  // 儲存紀錄到 localStorage
  useEffect(() => {
    localStorage.setItem('pomodoro-records', JSON.stringify(records))
  }, [records])

  // 儲存連續完成次數到 localStorage
  useEffect(() => {
    localStorage.setItem('pomodoro-consecutive-count', consecutiveCount.toString())
  }, [consecutiveCount])

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null

    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft(timeLeft => timeLeft - 1)
      }, 1000)
    } else if (timeLeft === 0) {
      // 時間到了，切換到休息或工作時間
      if (isBreak) {
        setTimeLeft(workMinutes * 60) // 工作時間
        setIsBreak(false)
      } else {
        // 工作時間完成，記錄完成時間
        try {
          const selectedFocusItem = focusItems.find(item => item.id === selectedFocusItemId)
          const selectedTag = taskTags.find(tag => tag.id === selectedTagId)
          const completedAt = new Date()
          const startTime = new Date(completedAt.getTime() - workMinutes * 60 * 1000)
          
          // 檢查必要欄位完整性
          const requiredFields = {
            id: Date.now().toString(),
            completedAt: completedAt.toISOString(),
            workMinutes: workMinutes,
            breakMinutes: breakMinutes,
            focusItemId: selectedFocusItemId,
            focusItemName: selectedFocusItem?.name || '未選擇',
            tagId: selectedTagId,
            tagName: selectedTag?.name || '未選擇',
            tagColor: selectedTag?.color || '#666666'
          }
          
          // 驗證必要欄位
          if (!requiredFields.id || !requiredFields.completedAt || 
              !requiredFields.workMinutes || requiredFields.workMinutes <= 0) {
            throw new Error('必要欄位缺失或無效')
          }
          
          const newRecord: PomodoroRecord = {
            ...requiredFields,
            title: `番茄鐘 ${workMinutes} 分鐘`,
            description: `完成 ${workMinutes} 分鐘專注工作，休息 ${breakMinutes} 分鐘`
          }
          
          // 記錄專注項目使用次數
          if (selectedFocusItemId) {
            recordFocusItemUsage(selectedFocusItemId)
          }
          
          // 記錄標籤使用次數
          if (selectedTagId) {
            recordTaskTagUsage(selectedTagId)
          }
          
          // 更新記憶體中的紀錄
          setRecords(prevRecords => [newRecord, ...prevRecords])
          
          // 儲存到 localStorage
          const updatedRecords = [newRecord, ...records]
          localStorage.setItem('pomodoro-records', JSON.stringify(updatedRecords))
          
          // 增加連續完成次數
          setConsecutiveCount(prev => prev + 1)
          
          // 顯示成功提示
          showExportStatus('success', '✅ 紀錄已儲存')
          
        } catch (error) {
          console.error('儲存番茄鐘紀錄失敗:', error)
          showExportStatus('error', '❌ 本次紀錄未成功儲存')
          return // 不繼續執行後續邏輯
        }
        
        // 如果休息時間為 0，直接跳過休息階段
        if (breakMinutes === 0) {
          setTimeLeft(workMinutes * 60) // 直接進入下一輪工作時間
          setIsBreak(false)
        } else {
          setTimeLeft(breakMinutes * 60) // 休息時間
          setIsBreak(true)
        }
      }
      setIsRunning(false)
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [isRunning, timeLeft, isBreak])

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
  }

  // 獲取今天的日期（yyyy-mm-dd 格式）
  const getTodayDate = () => {
    const today = new Date()
    const year = today.getFullYear()
    const month = String(today.getMonth() + 1).padStart(2, '0')
    const day = String(today.getDate()).padStart(2, '0')
    return `${year}-${month}-${day}`
  }

  // 計算進度百分比
  const getProgressPercentage = () => {
    const totalSeconds = isBreak ? breakMinutes * 60 : workMinutes * 60
    return ((totalSeconds - timeLeft) / totalSeconds) * 100
  }

  // 圓形計時器組件
  const CircularTimer = () => {
    const progress = getProgressPercentage()
    
    // 響應式尺寸 - 根據螢幕寬度調整
    const isMobile = typeof window !== 'undefined' && window.innerWidth <= 768
    const radius = isMobile ? 140 : 160
    const strokeWidth = isMobile ? 14 : 16
    const normalizedRadius = radius - strokeWidth * 2
    const circumference = normalizedRadius * 2 * Math.PI
    const strokeDasharray = `${circumference} ${circumference}`
    const strokeDashoffset = circumference - (progress / 100) * circumference

    // 獲取當前選擇的標籤顏色，如果沒有選擇則使用預設顏色
    const selectedTag = taskTags.find(tag => tag.id === selectedTagId)
    const timerColor = selectedTag?.color || (isBreak ? '#ff6b6b' : '#e74c3c')

    return (
      <div style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        position: 'relative',
        width: '100%',
        maxWidth: '400px',
        margin: '40px auto'
      }}>
        <svg
          width={radius * 2}
          height={radius * 2}
          style={{
            transform: 'rotate(-90deg)',
            filter: 'drop-shadow(0 6px 12px rgba(0, 0, 0, 0.15))',
            maxWidth: '100%',
            height: 'auto'
          }}
        >
          {/* 背景圓環 */}
          <circle
            stroke="#f0f0f0"
            fill="transparent"
            strokeWidth={strokeWidth}
            r={normalizedRadius}
            cx={radius}
            cy={radius}
            style={{
              strokeLinecap: 'round',
              opacity: 0.3
            }}
          />
          {/* 進度圓環 */}
          <circle
            stroke={timerColor}
            fill="transparent"
            strokeWidth={strokeWidth}
            strokeDasharray={strokeDasharray}
            style={{
              strokeDashoffset,
              strokeLinecap: 'round',
              transition: 'stroke-dashoffset 0.5s ease-in-out',
              filter: 'drop-shadow(0 2px 4px rgba(0, 0, 0, 0.1))'
            }}
            r={normalizedRadius}
            cx={radius}
            cy={radius}
          />
        </svg>
        
        {/* 中央時間顯示 */}
        <div style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          textAlign: 'center',
          color: timerColor,
          width: '100%',
          maxWidth: '200px'
        }}>
          <div style={{
            fontSize: isMobile ? '2.2rem' : '2.8rem',
            fontWeight: 'bold',
            lineHeight: 1,
            marginBottom: '8px',
            textShadow: '0 2px 4px rgba(0, 0, 0, 0.1)'
          }}>
            {formatTime(timeLeft)}
          </div>
          <div style={{
            fontSize: isMobile ? '0.9rem' : '1.1rem',
            fontWeight: '600',
            opacity: 0.9,
            textShadow: '0 1px 2px rgba(0, 0, 0, 0.1)'
          }}>
            {isBreak ? '休息時間' : '工作時間'}
          </div>
        </div>
      </div>
    )
  }

  const formatRecordTime = (isoString: string) => {
    const date = new Date(isoString)
    const year = date.getFullYear()
    const month = String(date.getMonth() + 1).padStart(2, '0')
    const day = String(date.getDate()).padStart(2, '0')
    const hours = String(date.getHours()).padStart(2, '0')
    const minutes = String(date.getMinutes()).padStart(2, '0')
    return `${year}/${month}/${day} ${hours}:${minutes}`
  }

  const clearRecords = () => {
    if (window.confirm('確定要清除所有完成紀錄嗎？')) {
      setRecords([])
    }
  }


  // 解析多關鍵字搜尋邏輯
  const parseSearchKeywords = (keyword: string) => {
    // 檢查是否包含 OR 條件（使用 | 或 or）
    if (keyword.includes('|') || keyword.toLowerCase().includes(' or ')) {
      // OR 邏輯：使用 | 或 or 分隔
      const orKeywords = keyword.split(/[|]| or /i).map(k => k.trim()).filter(k => k.length > 0)
      return { type: 'or', keywords: orKeywords }
    } else {
      // AND 邏輯：使用空格分隔
      const andKeywords = keyword.split(/\s+/).filter(k => k.length > 0)
      return { type: 'and', keywords: andKeywords }
    }
  }

  // 檢查單一欄位是否包含所有關鍵字（AND 邏輯）
  const checkFieldContainsAllKeywords = (fieldValue: string, keywords: string[]) => {
    return keywords.every(keyword => fieldValue.includes(keyword))
  }

  // 檢查單一欄位是否包含任一關鍵字（OR 邏輯）
  const checkFieldContainsAnyKeyword = (fieldValue: string, keywords: string[]) => {
    return keywords.some(keyword => fieldValue.includes(keyword))
  }

  // 建議關鍵字
  const suggestedKeywords = [
    '寫作', '讀書', '運動', '冥想', '工作', '會議', '學習', '專案', '程式設計', '設計',
    '運動｜冥想', '工作｜會議', '讀書｜學習', '寫作｜設計'
  ]

  // 載入搜尋歷史
  useEffect(() => {
    const savedHistory = localStorage.getItem('pomodoro-search-history')
    if (savedHistory) {
      try {
        const history = JSON.parse(savedHistory)
        setSearchHistory(Array.isArray(history) ? history : [])
      } catch (error) {
        console.error('載入搜尋歷史失敗:', error)
        setSearchHistory([])
      }
    }
  }, [])

  // 儲存搜尋歷史
  const saveSearchHistory = (keyword: string) => {
    if (!keyword.trim()) return
    
    const trimmedKeyword = keyword.trim()
    setSearchHistory(prev => {
      const newHistory = [trimmedKeyword, ...prev.filter(k => k !== trimmedKeyword)].slice(0, 5)
      localStorage.setItem('pomodoro-search-history', JSON.stringify(newHistory))
      return newHistory
    })
  }

  // 點擊建議或歷史關鍵字
  const handleKeywordClick = (keyword: string) => {
    setSearchKeyword(keyword)
    setShowSuggestions(false)
    setIsSearching(true)
    saveSearchHistory(keyword)
  }

  // 清除搜尋歷史
  const clearSearchHistory = () => {
    setSearchHistory([])
    localStorage.removeItem('pomodoro-search-history')
  }

  // 篩選紀錄
  const getFilteredRecords = () => {
    let filtered = records

    // 關鍵字搜尋
    if (searchKeyword.trim()) {
      const searchLogic = parseSearchKeywords(searchKeyword.trim())
      
      filtered = filtered.filter(record => {
        let fieldMatches = false
        
        // 根據選擇的欄位進行搜尋
        if (searchFields.focusItem) {
          // 比對專注項目名稱
          const focusItemName = record.focusItemName || ''
          const tagName = record.tagName || ''
          const focusFieldValue = `${focusItemName} ${tagName}`.trim()
          
          if (searchLogic.type === 'and') {
            if (checkFieldContainsAllKeywords(focusFieldValue, searchLogic.keywords)) fieldMatches = true
          } else {
            if (checkFieldContainsAnyKeyword(focusFieldValue, searchLogic.keywords)) fieldMatches = true
          }
        }
        
        if (searchFields.description) {
          // 比對標題和描述
          const title = record.title || ''
          const description = record.description || ''
          const descFieldValue = `${title} ${description}`.trim()
          
          if (searchLogic.type === 'and') {
            if (checkFieldContainsAllKeywords(descFieldValue, searchLogic.keywords)) fieldMatches = true
          } else {
            if (checkFieldContainsAnyKeyword(descFieldValue, searchLogic.keywords)) fieldMatches = true
          }
        }
        
        if (searchFields.time) {
          // 比對時間字串（完全符合）
          const completedAt = new Date(record.completedAt)
          const timeStr = completedAt.toLocaleString('zh-TW', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: false
          })
          
          if (searchLogic.type === 'and') {
            if (checkFieldContainsAllKeywords(timeStr, searchLogic.keywords)) fieldMatches = true
          } else {
            if (checkFieldContainsAnyKeyword(timeStr, searchLogic.keywords)) fieldMatches = true
          }
        }
        
        return fieldMatches
      })
    }

    // 日期範圍篩選
    if (startDate || endDate) {
      filtered = filtered.filter(record => {
        const recordDate = new Date(record.completedAt)
        const recordDateStr = recordDate.toISOString().split('T')[0] // yyyy-mm-dd

        if (startDate && endDate) {
          return recordDateStr >= startDate && recordDateStr <= endDate
        } else if (startDate) {
          return recordDateStr >= startDate
        } else if (endDate) {
          return recordDateStr <= endDate
        }
        return true
      })
    }

    return filtered
  }

  // 套用搜尋
  const applySearch = () => {
    setIsSearching(true)
  }

  // 清除搜尋
  const clearSearch = () => {
    setSearchKeyword('')
    setStartDate('')
    setEndDate('')
    setIsSearching(false)
  }

  // 專注項目管理函數
  const handleAddFocusItem = () => {
    if (newFocusItemName.trim()) {
      addFocusItem(newFocusItemName.trim())
      const updatedItems = getFocusItemsWithCount()
      setFocusItems(updatedItems)
      setNewFocusItemName('')
      setShowFocusItemModal(false)
    }
  }

  const handleEditFocusItem = (item: FocusItem) => {
    setEditingFocusItem(item)
    setEditingFocusItemName(item.name)
  }

  const handleUpdateFocusItem = () => {
    if (editingFocusItem && editingFocusItemName.trim()) {
      const success = updateFocusItem(editingFocusItem.id, editingFocusItemName.trim())
      if (success) {
        const updatedItems = getFocusItemsWithCount()
        setFocusItems(updatedItems)
        setEditingFocusItem(null)
        setEditingFocusItemName('')
      }
    }
  }

  const handleDeleteFocusItem = (id: string) => {
    if (window.confirm('確定要刪除這個專注項目嗎？')) {
      const success = deleteFocusItem(id)
      if (success) {
        const updatedItems = getFocusItemsWithCount()
        setFocusItems(updatedItems)
        // 如果刪除的是當前選中的項目，選擇第一個項目
        if (selectedFocusItemId === id && updatedItems.length > 0) {
          setSelectedFocusItemId(updatedItems[0].id)
        }
      }
    }
  }

  // 記錄編輯和刪除函數
  const handleEditRecord = (record: PomodoroRecord) => {
    setEditingRecord(record)
    setEditingRecordFocusItemId(record.focusItemId || '')
    // 將 ISO 日期轉換為 yyyy-mm-dd 格式
    const date = new Date(record.completedAt)
    const year = date.getFullYear()
    const month = String(date.getMonth() + 1).padStart(2, '0')
    const day = String(date.getDate()).padStart(2, '0')
    setEditingRecordCompletedAt(`${year}-${month}-${day}`)
  }

  const handleUpdateRecord = () => {
    if (editingRecord) {
      const selectedFocusItem = focusItems.find(item => item.id === editingRecordFocusItemId)
      const updatedRecord: PomodoroRecord = {
        ...editingRecord,
        focusItemId: editingRecordFocusItemId,
        focusItemName: selectedFocusItem?.name || '未選擇',
        completedAt: new Date(editingRecordCompletedAt).toISOString()
      }
      
      setRecords(prevRecords => 
        prevRecords.map(record => 
          record.id === editingRecord.id ? updatedRecord : record
        )
      )
      
      setEditingRecord(null)
      setEditingRecordFocusItemId('')
      setEditingRecordCompletedAt('')
    }
  }

  const handleDeleteRecord = (recordId: string) => {
    if (window.confirm('確定要刪除這筆記錄嗎？')) {
      setRecords(prevRecords => prevRecords.filter(record => record.id !== recordId))
    }
  }

  // 顯示匯出狀態訊息
  const showExportStatus = (type: 'success' | 'warning' | 'error', message: string) => {
    setExportStatus({
      show: true,
      type,
      message
    })
    
    // 5秒後自動隱藏
    setTimeout(() => {
      setExportStatus(prev => ({ ...prev, show: false }))
    }, 5000)
  }

  // 手動關閉狀態訊息
  const hideExportStatus = () => {
    setExportStatus(prev => ({ ...prev, show: false }))
  }

  // 計算每週統計資料
  const getWeeklyStats = () => {
    const now = new Date()
    const startOfWeek = new Date(now)
    startOfWeek.setDate(now.getDate() - now.getDay() + 1) // 週一開始
    startOfWeek.setHours(0, 0, 0, 0)
    
    const endOfWeek = new Date(startOfWeek)
    endOfWeek.setDate(startOfWeek.getDate() + 6) // 週日結束
    endOfWeek.setHours(23, 59, 59, 999)

    const weeklyData = [
      { day: '週一', count: 0, totalMinutes: 0 },
      { day: '週二', count: 0, totalMinutes: 0 },
      { day: '週三', count: 0, totalMinutes: 0 },
      { day: '週四', count: 0, totalMinutes: 0 },
      { day: '週五', count: 0, totalMinutes: 0 },
      { day: '週六', count: 0, totalMinutes: 0 },
      { day: '週日', count: 0, totalMinutes: 0 }
    ]

    records.forEach(record => {
      const recordDate = new Date(record.completedAt)
      if (recordDate >= startOfWeek && recordDate <= endOfWeek) {
        const dayOfWeek = recordDate.getDay()
        const dayIndex = dayOfWeek === 0 ? 6 : dayOfWeek - 1 // 週日調整為最後一個
        
        weeklyData[dayIndex].count += 1
        weeklyData[dayIndex].totalMinutes += record.workMinutes
      }
    })

    return weeklyData
  }

  const handleStart = () => {
    // 檢查是否已選擇任務項目
    if (!selectedFocusItemId) {
      showExportStatus('warning', '⚠️ 請先選擇一個任務項目')
      return
    }
    
    // 如果當前沒有在計時，重新設定時間
    if (!isRunning && timeLeft === 0) {
      setTimeLeft(isBreak ? breakMinutes * 60 : workMinutes * 60)
    }
    setIsRunning(true)
  }

  const handlePause = () => {
    setIsRunning(false)
  }

  const handleReset = () => {
    setIsRunning(false)
    setIsBreak(false)
    setTimeLeft(workMinutes * 60)
  }

  return (
    <div className="page">
      <Link 
        to="/" 
        style={{ 
          textDecoration: 'none',
          display: 'inline-block',
          marginBottom: '20px'
        }}
      >
        <button style={{
          backgroundColor: '#f3f3f3',
          color: '#333',
          border: 'none',
          borderRadius: '8px',
          padding: '12px 20px',
          fontSize: '16px',
          fontWeight: '500',
          cursor: 'pointer',
          transition: 'all 0.2s'
        }}
        onMouseOver={(e) => {
          e.currentTarget.style.backgroundColor = '#e8e8e8'
        }}
        onMouseOut={(e) => {
          e.currentTarget.style.backgroundColor = '#f3f3f3'
        }}
        >
          ← 回首頁
        </button>
      </Link>
      
      <h1>🍅 番茄鐘</h1>
      
      {/* 匯出狀態訊息 */}
      {exportStatus.show && (
        <div style={{
          position: 'fixed',
          top: '20px',
          left: '50%',
          transform: 'translateX(-50%)',
          zIndex: 9999,
          maxWidth: '400px',
          width: '90%',
          padding: '12px 20px',
          borderRadius: '8px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          animation: 'slideDown 0.3s ease-out',
          backgroundColor: exportStatus.type === 'success' ? '#d4edda' : 
                          exportStatus.type === 'warning' ? '#fff3cd' : '#f8d7da',
          border: `1px solid ${exportStatus.type === 'success' ? '#c3e6cb' : 
                              exportStatus.type === 'warning' ? '#ffeaa7' : '#f5c6cb'}`,
          color: exportStatus.type === 'success' ? '#28a745' : 
                 exportStatus.type === 'warning' ? '#856404' : '#721c24'
        }}>
          <div style={{
            fontSize: '14px',
            fontWeight: '600',
            flex: 1
          }}>
            {exportStatus.message}
          </div>
          <button
            onClick={hideExportStatus}
            style={{
              background: 'none',
              border: 'none',
              fontSize: '18px',
              cursor: 'pointer',
              color: 'inherit',
              opacity: 0.7,
              marginLeft: '10px',
              padding: '0',
              width: '20px',
              height: '20px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}
            onMouseOver={(e) => {
              e.currentTarget.style.opacity = '1'
            }}
            onMouseOut={(e) => {
              e.currentTarget.style.opacity = '0.7'
            }}
          >
            ×
          </button>
        </div>
      )}
      
      {/* 圓形計時器 */}
      <CircularTimer />

      {/* 連續完成次數顯示 */}
      {consecutiveCount > 0 && (
        <div style={{
          textAlign: 'center',
          margin: '20px 0',
          padding: '15px',
          backgroundColor: '#e8f5e8',
          borderRadius: '12px',
          border: '2px solid #4caf50'
        }}>
          <div style={{
            fontSize: '18px',
            fontWeight: '600',
            color: '#2e7d32',
            marginBottom: '5px'
          }}>
            🎉 連續完成 {consecutiveCount} 輪番茄鐘！
          </div>
          <div style={{
            fontSize: '14px',
            color: '#388e3c'
          }}>
            保持專注，繼續加油！
          </div>
        </div>
      )}

      {/* 專注項目選擇區域 */}
      <div style={{
        backgroundColor: '#f8f9fa',
        padding: '25px',
        borderRadius: '12px',
        margin: '30px 0',
        border: '1px solid #e0e0e0'
      }}>
        <h3 style={{ 
          margin: '0 0 20px 0', 
          color: '#333',
          fontSize: '1.3rem',
          fontWeight: '600'
        }}>
          🎯 專注項目
        </h3>
        
        {/* 專注項目選擇下拉選單 */}
        <div style={{ marginBottom: '20px' }}>
          <select
            value={selectedFocusItemId}
            onChange={(e) => setSelectedFocusItemId(e.target.value)}
            style={{
              width: '100%',
              padding: '12px 16px',
              fontSize: '16px',
              border: '2px solid #e0e0e0',
              borderRadius: '8px',
              backgroundColor: '#fff',
              color: '#333',
              outline: 'none',
              transition: 'border-color 0.2s'
            }}
            onFocus={(e) => {
              e.target.style.borderColor = '#4ecdc4'
            }}
            onBlur={(e) => {
              e.target.style.borderColor = '#e0e0e0'
            }}
          >
            {focusItems.map((item) => (
              <option key={item.id} value={item.id}>
                {item.name} {item.usageCount > 0 && `(${item.usageCount}次)`}
              </option>
            ))}
          </select>
        </div>

        {/* 專注項目管理按鈕 */}
        <div style={{
          display: 'flex',
          gap: '10px',
          flexWrap: 'wrap',
          justifyContent: 'center'
        }}>
          <button
            onClick={() => setShowFocusItemModal(true)}
            style={{
              padding: '10px 20px',
              backgroundColor: '#4ecdc4',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              fontSize: '14px',
              fontWeight: '600',
              cursor: 'pointer',
              transition: 'background-color 0.2s'
            }}
            onMouseOver={(e) => {
              e.currentTarget.style.backgroundColor = '#45b7aa'
            }}
            onMouseOut={(e) => {
              e.currentTarget.style.backgroundColor = '#4ecdc4'
            }}
          >
            ➕ 新增項目
          </button>
          
          <button
            onClick={() => {
              const items = getFocusItemsWithCount()
              setFocusItems(items)
            }}
            style={{
              padding: '10px 20px',
              backgroundColor: '#6c757d',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              fontSize: '14px',
              fontWeight: '600',
              cursor: 'pointer',
              transition: 'background-color 0.2s'
            }}
            onMouseOver={(e) => {
              e.currentTarget.style.backgroundColor = '#5a6268'
            }}
            onMouseOut={(e) => {
              e.currentTarget.style.backgroundColor = '#6c757d'
            }}
          >
            🔄 重新整理
          </button>
        </div>
      </div>

      {/* 標籤選擇區域 */}
      <div style={{
        backgroundColor: '#f8f9fa',
        padding: '25px',
        borderRadius: '12px',
        margin: '30px 0',
        border: '1px solid #e0e0e0'
      }}>
        <h3 style={{ 
          margin: '0 0 20px 0', 
          color: '#333',
          fontSize: '1.3rem',
          fontWeight: '600'
        }}>
          🏷️ 任務標籤
        </h3>
        
        {/* 標籤選擇區域 */}
        <div style={{ marginBottom: '20px' }}>
          <div style={{
            display: 'flex',
            flexWrap: 'wrap',
            gap: '8px',
            marginBottom: '15px'
          }}>
            {taskTags.map((tag) => (
              <button
                key={tag.id}
                onClick={() => setSelectedTagId(tag.id)}
                style={{
                  padding: '8px 16px',
                  backgroundColor: selectedTagId === tag.id ? tag.color : '#f0f0f0',
                  color: selectedTagId === tag.id ? 'white' : '#333',
                  border: `2px solid ${selectedTagId === tag.id ? tag.color : '#e0e0e0'}`,
                  borderRadius: '20px',
                  fontSize: '14px',
                  fontWeight: '600',
                  cursor: 'pointer',
                  transition: 'all 0.2s',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px'
                }}
                onMouseOver={(e) => {
                  if (selectedTagId !== tag.id) {
                    e.currentTarget.style.backgroundColor = tag.color
                    e.currentTarget.style.color = 'white'
                    e.currentTarget.style.borderColor = tag.color
                  }
                }}
                onMouseOut={(e) => {
                  if (selectedTagId !== tag.id) {
                    e.currentTarget.style.backgroundColor = '#f0f0f0'
                    e.currentTarget.style.color = '#333'
                    e.currentTarget.style.borderColor = '#e0e0e0'
                  }
                }}
              >
                <div 
                  className="color-dot"
                  style={{
                    width: '12px',
                    height: '12px',
                    borderRadius: '50%',
                    backgroundColor: selectedTagId === tag.id ? 'white' : tag.color,
                    border: '2px solid #ffffff',
                    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.3)'
                  }} 
                />
                {tag.name}
                {tag.usageCount > 0 && (
                  <span style={{
                    fontSize: '12px',
                    opacity: 0.8
                  }}>
                    ({tag.usageCount})
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* 標籤管理按鈕 */}
        <div style={{
          display: 'flex',
          gap: '10px',
          flexWrap: 'wrap',
          justifyContent: 'center'
        }}>
          <button
            onClick={() => setShowTagModal(true)}
            style={{
              padding: '10px 20px',
              backgroundColor: '#2196f3',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              fontSize: '14px',
              fontWeight: '600',
              cursor: 'pointer',
              transition: 'background-color 0.2s'
            }}
            onMouseOver={(e) => {
              e.currentTarget.style.backgroundColor = '#1976d2'
            }}
            onMouseOut={(e) => {
              e.currentTarget.style.backgroundColor = '#2196f3'
            }}
          >
            ➕ 管理標籤
          </button>
        </div>
      </div>

      {/* 時間設定區域 */}
      <div style={{
        backgroundColor: '#f8f9fa',
        padding: '25px',
        borderRadius: '12px',
        marginBottom: '30px',
        border: '1px solid #e9ecef',
        maxWidth: '500px',
        margin: '0 auto 30px auto'
      }}>
        <h3 style={{
          margin: '0 0 20px 0',
          color: '#333',
          fontSize: '1.2rem',
          fontWeight: '600',
          textAlign: 'center'
        }}>
          ⚙️ 時間設定
        </h3>
        
        <div style={{
          display: 'flex',
          gap: '20px',
          justifyContent: 'center',
          alignItems: 'center',
          flexWrap: 'wrap'
        }}>
          {/* 工作時間設定 */}
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            <label style={{
              fontSize: '14px',
              color: '#666',
              marginBottom: '8px',
              fontWeight: '500'
            }}>
              工作時間（分鐘）
            </label>
            <input
              type="number"
              min="1"
              max="60"
              value={workMinutes}
              onChange={(e) => {
                const value = parseInt(e.target.value) || 25
                setWorkMinutes(value)
                if (!isRunning && !isBreak) {
                  setTimeLeft(value * 60)
                }
              }}
              style={{
                width: '80px',
                padding: '10px 12px',
                fontSize: '16px',
                border: '2px solid #e0e0e0',
                borderRadius: '8px',
                textAlign: 'center',
                fontWeight: '600',
                color: '#333',
                backgroundColor: '#fff',
                outline: 'none',
                transition: 'border-color 0.2s'
              }}
              onFocus={(e) => {
                e.target.style.borderColor = '#4ecdc4'
              }}
              onBlur={(e) => {
                e.target.style.borderColor = '#e0e0e0'
              }}
            />
          </div>

          {/* 分隔線 */}
          <div style={{
            width: '1px',
            height: '40px',
            backgroundColor: '#ddd',
            margin: '0 10px'
          }} />

          {/* 休息時間設定 */}
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            <label style={{
              fontSize: '14px',
              color: '#666',
              marginBottom: '8px',
              fontWeight: '500'
            }}>
              休息時間（分鐘）
            </label>
            <input
              type="number"
              min="0"
              max="30"
              value={breakMinutes}
              onChange={(e) => {
                const value = parseInt(e.target.value) || 0
                setBreakMinutes(value)
              }}
              style={{
                width: '80px',
                padding: '10px 12px',
                fontSize: '16px',
                border: '2px solid #e0e0e0',
                borderRadius: '8px',
                textAlign: 'center',
                fontWeight: '600',
                color: '#333',
                backgroundColor: '#fff',
                outline: 'none',
                transition: 'border-color 0.2s'
              }}
              onFocus={(e) => {
                e.target.style.borderColor = '#4ecdc4'
              }}
              onBlur={(e) => {
                e.target.style.borderColor = '#e0e0e0'
              }}
            />
          </div>
        </div>
      </div>
      
      <div style={{ display: 'flex', gap: '20px', justifyContent: 'center' }}>
        {!isRunning ? (
          <button onClick={handleStart} style={{ 
            backgroundColor: '#4ecdc4', 
            color: 'white',
            padding: '18px 36px',
            fontSize: '1.3rem',
            fontWeight: '600'
          }}>
            開始計時
          </button>
        ) : (
          <button onClick={handlePause} style={{ 
            backgroundColor: '#ff6b6b', 
            color: 'white',
            padding: '18px 36px',
            fontSize: '1.3rem',
            fontWeight: '600'
          }}>
            暫停計時
          </button>
        )}
        
        <button onClick={handleReset} style={{ 
          backgroundColor: '#95a5a6', 
          color: 'white',
          padding: '18px 36px',
          fontSize: '1.3rem',
          fontWeight: '600'
        }}>
          重新開始
        </button>
      </div>

      {/* 每週統計圖表區塊 */}
      <div className="bg-gray-50 p-4 sm:p-6 rounded-xl mx-auto border border-gray-200" style={{
        margin: '30px auto',
        maxWidth: '600px'
      }}>
        <h3 className="text-lg sm:text-xl font-semibold text-center text-gray-800 mb-5">
          📊 本週統計
        </h3>
        
        {(() => {
          const weeklyData = getWeeklyStats()
          const hasData = weeklyData.some(day => day.count > 0)
          
          if (!hasData) {
            return (
              <div className="text-center py-10 px-5 text-gray-600 text-lg font-medium">
                📅 本週尚無完成紀錄
              </div>
            )
          }
          
          const maxCount = Math.max(...weeklyData.map(day => day.count))
          
          return (
            <div className="flex flex-col gap-3 px-2 sm:px-4">
              {weeklyData.map((day, index) => (
                <div key={index} className="flex items-center gap-3 min-h-10">
                  {/* 日期標籤 */}
                  <div className="w-12 sm:w-14 text-sm sm:text-base font-semibold text-gray-700 text-center flex-shrink-0">
                    {day.day}
                  </div>
                  
                  {/* 圖表條 */}
                  <div className="flex-1 h-8 bg-gray-200 rounded-full relative overflow-hidden min-w-24">
                    <div 
                      className="h-full rounded-full transition-all duration-300 flex items-center justify-end pr-2"
                      style={{
                        width: maxCount > 0 ? `${(day.count / maxCount) * 100}%` : '0%',
                        backgroundColor: day.count > 0 ? '#4ecdc4' : '#e9ecef'
                      }}
                    >
                      {day.count > 0 && (
                        <span className="text-white text-xs font-semibold drop-shadow-sm">
                          {day.count} 顆
                        </span>
                      )}
                    </div>
                  </div>
                  
                  {/* 數值顯示 */}
                  <div className="w-16 sm:w-20 text-right text-sm sm:text-base font-semibold flex-shrink-0 flex items-center justify-end pr-3">
                    <span className={day.count > 0 ? 'text-teal-500' : 'text-gray-400'}>
                      {day.count > 0 ? `${day.count} 顆` : '0 顆'}
                    </span>
                  </div>
                </div>
              ))}
              
              {/* 統計摘要 */}
              <div className="mt-5 p-4 bg-green-50 rounded-lg border border-green-200">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                  <div className="text-sm sm:text-base font-semibold text-green-700">
                    🍅 本週總計：{weeklyData.reduce((sum, day) => sum + day.count, 0)} 顆番茄
                  </div>
                  <div className="text-sm sm:text-base font-semibold text-green-700">
                    ⏱️ 總時長：{weeklyData.reduce((sum, day) => sum + day.totalMinutes, 0)} 分鐘
                  </div>
                </div>
              </div>
            </div>
          )
        })()}
      </div>

      {/* 完成紀錄區塊 */}
      <div style={{
        marginTop: '50px',
        maxWidth: '600px',
        margin: '50px auto 0 auto'
      }}>
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '20px'
        }}>
          <h3 className="text-lg sm:text-xl font-semibold text-gray-800 m-0">
            📊 完成紀錄
          </h3>
          
          <div style={{
            display: 'flex',
            flexDirection: 'column',
            gap: '10px',
            alignItems: 'center'
          }}>
            {/* 匯出狀態提示 */}
            {exportStatus.show && exportStatus.type === 'success' && (
              <div style={{
                padding: '8px 16px',
                backgroundColor: '#d4edda',
                border: '1px solid #c3e6cb',
                borderRadius: '6px',
                color: '#28a745',
                fontSize: '14px',
                fontWeight: '600',
                textAlign: 'center',
                animation: 'slideDown 0.3s ease-out'
              }}>
                {exportStatus.message}
              </div>
            )}
            
            <div style={{
              display: 'flex',
              gap: '10px',
              alignItems: 'center'
            }}>
              {/* 匯出 CSV 按鈕 */}
            <button
              onClick={() => {
                // 取得目前搜尋結果
                const filteredRecords = getFilteredRecords()
                
                if (filteredRecords.length === 0) {
                  showExportStatus('warning', '⚠️ 目前無可匯出的紀錄')
                  return
                }
                
                // 立即顯示成功提示
                showExportStatus('success', `✅ 已成功匯出 ${filteredRecords.length} 筆紀錄！`)
                
                // 執行匯出
                exportPomodoroRecordsToCSV(filteredRecords)
              }}
              disabled={getFilteredRecords().length === 0}
              style={{
                padding: '8px 16px',
                backgroundColor: getFilteredRecords().length > 0 ? '#28a745' : '#ccc',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                fontSize: '14px',
                fontWeight: '500',
                cursor: getFilteredRecords().length > 0 ? 'pointer' : 'not-allowed',
                transition: 'background-color 0.2s',
                display: 'flex',
                alignItems: 'center',
                gap: '6px'
              }}
              onMouseOver={(e) => {
                if (getFilteredRecords().length > 0) {
                  e.currentTarget.style.backgroundColor = '#218838'
                }
              }}
              onMouseOut={(e) => {
                if (getFilteredRecords().length > 0) {
                  e.currentTarget.style.backgroundColor = '#28a745'
                }
              }}
              title="僅匯出目前搜尋結果的紀錄資料（不包含全部）"
            >
              💾 匯出目前結果
            </button>
            
            {records.length > 0 && (
            <button
              onClick={clearRecords}
              style={{
                backgroundColor: '#ff6b6b',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                padding: '8px 16px',
                fontSize: '14px',
                fontWeight: '500',
                cursor: 'pointer',
                transition: 'background-color 0.2s'
              }}
              onMouseOver={(e) => {
                e.currentTarget.style.backgroundColor = '#ff5252'
              }}
              onMouseOut={(e) => {
                e.currentTarget.style.backgroundColor = '#ff6b6b'
              }}
            >
              清除紀錄
            </button>
            )}
            </div>
          </div>
        </div>

        {/* 搜尋功能區塊 */}
        {records.length > 0 && (
          <div style={{
            backgroundColor: '#f8f9fa',
            padding: '20px',
            borderRadius: '12px',
            marginBottom: '20px',
            border: '1px solid #e9ecef'
          }}>
            <h4 style={{
              margin: '0 0 15px 0',
              color: '#333',
              fontSize: '1.1rem',
              fontWeight: '600'
            }}>
              🔍 搜尋紀錄
            </h4>
            
            {/* 搜尋輸入區域 */}
            <div style={{ marginBottom: '15px' }}>
              <div style={{
                display: 'flex',
                gap: '10px',
                alignItems: 'center',
                marginBottom: '10px'
              }}>
                {/* 搜尋輸入框 */}
                <div style={{ flex: 1, position: 'relative' }}>
                  <input
                    type="text"
                    placeholder="輸入關鍵字搜尋紀錄…"
                    value={searchKeyword}
                    onChange={(e) => {
                      setSearchKeyword(e.target.value)
                      setShowSuggestions(e.target.value.trim() === '')
                    }}
                    onFocus={() => {
                      setIsSearchInputFocused(true)
                      setShowSuggestions(true)
                    }}
                    onBlur={() => {
                      setIsSearchInputFocused(false)
                      // 延遲隱藏建議，讓點擊事件能夠觸發
                      setTimeout(() => setShowSuggestions(false), 200)
                    }}
                    style={{
                      width: '100%',
                      padding: '12px 16px',
                      fontSize: '16px',
                      border: '2px solid #e0e0e0',
                      borderRadius: '8px',
                      backgroundColor: '#fff',
                      color: '#333',
                      outline: 'none',
                      transition: 'border-color 0.2s',
                      boxSizing: 'border-box'
                    }}
                  />
                </div>

                {/* 搜尋按鈕 */}
                <button
                  onClick={() => {
                    if (searchKeyword.trim()) {
                      setIsSearching(true)
                      saveSearchHistory(searchKeyword)
                    }
                  }}
                  style={{
                    padding: '12px 20px',
                    backgroundColor: '#4ecdc4',
                    color: 'white',
                    border: 'none',
                    borderRadius: '8px',
                    fontSize: '14px',
                    fontWeight: '600',
                    cursor: 'pointer',
                    transition: 'background-color 0.2s',
                    whiteSpace: 'nowrap'
                  }}
                  onMouseOver={(e) => {
                    e.currentTarget.style.backgroundColor = '#45b7b8'
                  }}
                  onMouseOut={(e) => {
                    e.currentTarget.style.backgroundColor = '#4ecdc4'
                  }}
                >
                  🔍 搜尋
                </button>
              </div>

              {/* 搜尋建議和歷史 */}
              {showSuggestions && isSearchInputFocused && (
                <div style={{
                  backgroundColor: '#fff',
                  border: '1px solid #e0e0e0',
                  borderRadius: '8px',
                  boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
                  padding: '12px',
                  marginTop: '5px',
                  zIndex: 1000,
                  position: 'relative'
                }}>
                  {/* 最近搜尋 */}
                  {searchHistory.length > 0 && (
                    <div style={{ marginBottom: '12px' }}>
                      <div style={{
                        fontSize: '12px',
                        color: '#666',
                        marginBottom: '6px',
                        fontWeight: '600'
                      }}>
                        🕒 最近搜尋：
                      </div>
                      <div style={{
                        display: 'flex',
                        gap: '8px',
                        flexWrap: 'wrap'
                      }}>
                        {searchHistory.map((keyword, index) => (
                          <button
                            key={index}
                            onClick={() => handleKeywordClick(keyword)}
                            style={{
                              padding: '4px 8px',
                              backgroundColor: '#f8f9fa',
                              border: '1px solid #dee2e6',
                              borderRadius: '4px',
                              fontSize: '12px',
                              color: '#495057',
                              cursor: 'pointer',
                              transition: 'all 0.2s'
                            }}
                            onMouseOver={(e) => {
                              e.currentTarget.style.backgroundColor = '#e9ecef'
                            }}
                            onMouseOut={(e) => {
                              e.currentTarget.style.backgroundColor = '#f8f9fa'
                            }}
                          >
                            {keyword}
                          </button>
                        ))}
                        <button
                          onClick={clearSearchHistory}
                          style={{
                            padding: '4px 8px',
                            backgroundColor: 'transparent',
                            border: '1px solid #dc3545',
                            borderRadius: '4px',
                            fontSize: '12px',
                            color: '#dc3545',
                            cursor: 'pointer',
                            transition: 'all 0.2s'
                          }}
                          onMouseOver={(e) => {
                            e.currentTarget.style.backgroundColor = '#dc3545'
                            e.currentTarget.style.color = 'white'
                          }}
                          onMouseOut={(e) => {
                            e.currentTarget.style.backgroundColor = 'transparent'
                            e.currentTarget.style.color = '#dc3545'
                          }}
                        >
                          清除
                        </button>
                      </div>
                    </div>
                  )}

                  {/* 熱門建議 */}
                  <div>
                    <div style={{
                      fontSize: '12px',
                      color: '#666',
                      marginBottom: '6px',
                      fontWeight: '600'
                    }}>
                      🔥 熱門建議：
                    </div>
                    <div style={{
                      display: 'flex',
                      gap: '8px',
                      flexWrap: 'wrap'
                    }}>
                      {suggestedKeywords.slice(0, 8).map((keyword, index) => (
                        <button
                          key={index}
                          onClick={() => handleKeywordClick(keyword)}
                          style={{
                            padding: '4px 8px',
                            backgroundColor: '#e3f2fd',
                            border: '1px solid #bbdefb',
                            borderRadius: '4px',
                            fontSize: '12px',
                            color: '#1976d2',
                            cursor: 'pointer',
                            transition: 'all 0.2s'
                          }}
                          onMouseOver={(e) => {
                            e.currentTarget.style.backgroundColor = '#bbdefb'
                          }}
                          onMouseOut={(e) => {
                            e.currentTarget.style.backgroundColor = '#e3f2fd'
                          }}
                        >
                          {keyword}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* 搜尋欄位選擇器 */}
            <div style={{ marginBottom: '15px' }}>
              <label style={{
                display: 'block',
                marginBottom: '8px',
                fontSize: '14px',
                fontWeight: '600',
                color: '#555'
              }}>
                🔽 選擇欄位：
              </label>
              <div style={{
                display: 'flex',
                gap: '20px',
                flexWrap: 'wrap',
                alignItems: 'center',
                marginBottom: '10px'
              }}>
                <button
                  onClick={() => setSearchFields({
                    focusItem: true,
                    description: true,
                    time: true
                  })}
                  style={{
                    padding: '4px 8px',
                    fontSize: '12px',
                    backgroundColor: '#f8f9fa',
                    border: '1px solid #dee2e6',
                    borderRadius: '4px',
                    color: '#495057',
                    cursor: 'pointer',
                    transition: 'all 0.2s'
                  }}
                  onMouseOver={(e) => {
                    e.currentTarget.style.backgroundColor = '#e9ecef'
                  }}
                  onMouseOut={(e) => {
                    e.currentTarget.style.backgroundColor = '#f8f9fa'
                  }}
                >
                  全選
                </button>
                <button
                  onClick={() => setSearchFields({
                    focusItem: false,
                    description: false,
                    time: false
                  })}
                  style={{
                    padding: '4px 8px',
                    fontSize: '12px',
                    backgroundColor: '#f8f9fa',
                    border: '1px solid #dee2e6',
                    borderRadius: '4px',
                    color: '#495057',
                    cursor: 'pointer',
                    transition: 'all 0.2s'
                  }}
                  onMouseOver={(e) => {
                    e.currentTarget.style.backgroundColor = '#e9ecef'
                  }}
                  onMouseOut={(e) => {
                    e.currentTarget.style.backgroundColor = '#f8f9fa'
                  }}
                >
                  全不選
                </button>
              </div>
              
              <div style={{
                display: 'flex',
                gap: '20px',
                flexWrap: 'wrap',
                alignItems: 'center'
              }}>
                <label style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  fontSize: '14px',
                  color: '#333',
                  cursor: 'pointer'
                }}>
                  <input
                    type="checkbox"
                    checked={searchFields.focusItem}
                    onChange={(e) => setSearchFields(prev => ({
                      ...prev,
                      focusItem: e.target.checked
                    }))}
                    style={{
                      width: '16px',
                      height: '16px',
                      accentColor: '#4ecdc4'
                    }}
                  />
                  <span>專注任務名稱</span>
                </label>
                
                <label style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  fontSize: '14px',
                  color: '#333',
                  cursor: 'pointer'
                }}>
                  <input
                    type="checkbox"
                    checked={searchFields.description}
                    onChange={(e) => setSearchFields(prev => ({
                      ...prev,
                      description: e.target.checked
                    }))}
                    style={{
                      width: '16px',
                      height: '16px',
                      accentColor: '#4ecdc4'
                    }}
                  />
                  <span>任務內容/描述</span>
                </label>
                
                <label style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  fontSize: '14px',
                  color: '#333',
                  cursor: 'pointer'
                }}>
                  <input
                    type="checkbox"
                    checked={searchFields.time}
                    onChange={(e) => setSearchFields(prev => ({
                      ...prev,
                      time: e.target.checked
                    }))}
                    style={{
                      width: '16px',
                      height: '16px',
                      accentColor: '#4ecdc4'
                    }}
                  />
                  <span>開始/結束時間</span>
                </label>
              </div>
            </div>

            {/* 日期範圍搜尋 */}
            <div style={{
              display: 'flex',
              gap: '15px',
              alignItems: 'center',
              flexWrap: 'wrap',
              marginBottom: '15px'
            }}>
              <div style={{ flex: 1, minWidth: '150px' }}>
                <label style={{
                  display: 'block',
                  fontSize: '14px',
                  color: '#666',
                  marginBottom: '5px',
                  fontWeight: '500'
                }}>
                  開始日期
                </label>
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  style={{
                    width: '100%',
                    padding: '10px 12px',
                    fontSize: '16px',
                    border: '2px solid #e0e0e0',
                    borderRadius: '8px',
                    backgroundColor: '#fff',
                    color: '#333',
                    outline: 'none',
                    transition: 'border-color 0.2s',
                    boxSizing: 'border-box'
                  }}
                  onFocus={(e) => {
                    e.target.style.borderColor = '#4ecdc4'
                  }}
                  onBlur={(e) => {
                    e.target.style.borderColor = '#e0e0e0'
                  }}
                />
              </div>
              
              <div style={{ flex: 1, minWidth: '150px' }}>
                <label style={{
                  display: 'block',
                  fontSize: '14px',
                  color: '#666',
                  marginBottom: '5px',
                  fontWeight: '500'
                }}>
                  結束日期
                </label>
                <input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  style={{
                    width: '100%',
                    padding: '10px 12px',
                    fontSize: '16px',
                    border: '2px solid #e0e0e0',
                    borderRadius: '8px',
                    backgroundColor: '#fff',
                    color: '#333',
                    outline: 'none',
                    transition: 'border-color 0.2s',
                    boxSizing: 'border-box'
                  }}
                  onFocus={(e) => {
                    e.target.style.borderColor = '#4ecdc4'
                  }}
                  onBlur={(e) => {
                    e.target.style.borderColor = '#e0e0e0'
                  }}
                />
              </div>
            </div>

            {/* 搜尋按鈕 */}
            <div style={{
              display: 'flex',
              gap: '10px',
              justifyContent: 'flex-end'
            }}>
              <button
                onClick={clearSearch}
                style={{
                  backgroundColor: '#95a5a6',
                  color: 'white',
                  border: 'none',
                  borderRadius: '6px',
                  padding: '10px 20px',
                  fontSize: '14px',
                  fontWeight: '500',
                  cursor: 'pointer',
                  transition: 'background-color 0.2s'
                }}
                onMouseOver={(e) => {
                  e.currentTarget.style.backgroundColor = '#7f8c8d'
                }}
                onMouseOut={(e) => {
                  e.currentTarget.style.backgroundColor = '#95a5a6'
                }}
              >
                清除搜尋
              </button>
              <button
                onClick={applySearch}
                style={{
                  backgroundColor: '#4ecdc4',
                  color: 'white',
                  border: 'none',
                  borderRadius: '6px',
                  padding: '10px 20px',
                  fontSize: '14px',
                  fontWeight: '500',
                  cursor: 'pointer',
                  transition: 'background-color 0.2s'
                }}
                onMouseOver={(e) => {
                  e.currentTarget.style.backgroundColor = '#45b7b8'
                }}
                onMouseOut={(e) => {
                  e.currentTarget.style.backgroundColor = '#4ecdc4'
                }}
              >
                套用搜尋
              </button>
            </div>
          </div>
        )}

        {records.length === 0 ? (
          <div style={{
            textAlign: 'center',
            color: '#666',
            fontSize: '16px',
            padding: '40px 20px',
            backgroundColor: '#f8f9fa',
            borderRadius: '12px',
            border: '1px solid #e9ecef'
          }}>
            🍅 還沒有完成紀錄<br />
            完成一次番茄鐘後會顯示在這裡
          </div>
        ) : (() => {
          const filteredRecords = getFilteredRecords()
          const displayRecords = isSearching ? filteredRecords : records
          
          return (
            <>
              {isSearching && (
                <div style={{
                  marginBottom: '15px',
                  padding: '10px 15px',
                  backgroundColor: filteredRecords.length > 0 ? '#e3f2fd' : '#fff3cd',
                  borderRadius: '8px',
                  border: `1px solid ${filteredRecords.length > 0 ? '#bbdefb' : '#ffeaa7'}`,
                  fontSize: '14px',
                  color: filteredRecords.length > 0 ? '#1976d2' : '#856404'
                }}>
                  {filteredRecords.length > 0 ? (
                    <>
                      🔍 搜尋結果：找到 {filteredRecords.length} 筆紀錄
                      {(searchKeyword || startDate || endDate) && (
                        <span style={{ marginLeft: '10px', fontSize: '12px', color: '#666' }}>
                          （關鍵字：{searchKeyword || '無'} | 欄位：{[
                            searchFields.focusItem && '專注任務',
                            searchFields.description && '內容描述',
                            searchFields.time && '時間'
                          ].filter(Boolean).join('、')} | 日期：{startDate || '不限'} ～ {endDate || '不限'}）
                        </span>
                      )}
                    </>
                  ) : (
                    <>
                      ⚠️ 未找到符合「{searchKeyword}」的紀錄
                      {(startDate || endDate) && (
                        <span style={{ marginLeft: '10px', fontSize: '12px', color: '#666' }}>
                          （日期：{startDate || '不限'} ～ {endDate || '不限'}）
                        </span>
                      )}
                    </>
                  )}
                </div>
              )}
              
              {displayRecords.length === 0 ? (
                <div style={{
                  textAlign: 'center',
                  color: '#666',
                  fontSize: '16px',
                  padding: '40px 20px',
                  backgroundColor: '#f8f9fa',
                  borderRadius: '12px',
                  border: '1px solid #e9ecef'
                }}>
                  {isSearching ? (
                    <>
                      ⚠️ 未找到符合「{searchKeyword}」的紀錄<br />
                      請嘗試其他關鍵字或調整搜尋條件
                    </>
                  ) : (
                    <>
                      🍅 還沒有完成紀錄<br />
                      完成一次番茄鐘後會顯示在這裡
                    </>
                  )}
                </div>
              ) : (
                <div style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '12px'
                }}>
                  {displayRecords.map((record) => (
              <div
                key={record.id}
                style={{
                  backgroundColor: '#ffffff',
                  border: '1px solid #e0e0e0',
                  borderRadius: '10px',
                  padding: '16px 20px',
                  boxShadow: '0 2px 4px rgba(0, 0, 0, 0.05)',
                  transition: 'all 0.2s'
                }}
                onMouseOver={(e) => {
                  e.currentTarget.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.1)'
                  e.currentTarget.style.transform = 'translateY(-1px)'
                }}
                onMouseOut={(e) => {
                  e.currentTarget.style.boxShadow = '0 2px 4px rgba(0, 0, 0, 0.05)'
                  e.currentTarget.style.transform = 'translateY(0)'
                }}
              >
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px'
                }}>
                  <div style={{
                    fontSize: '20px'
                  }}>
                    ✅
                  </div>
                  <div style={{
                    flex: 1
                  }}>
                    <div style={{
                      fontSize: '16px',
                      fontWeight: '600',
                      color: '#333',
                      marginBottom: '4px'
                    }}>
                      {record.title || '完成一輪'}
                    </div>
                    <div style={{
                      fontSize: '14px',
                      color: '#666',
                      marginBottom: '6px'
                    }}>
                      {formatRecordTime(record.completedAt)}
                    </div>
                    {record.focusItemName && (
                      <div style={{
                        fontSize: '13px',
                        color: '#4ecdc4',
                        fontWeight: '600',
                        marginBottom: '4px',
                        backgroundColor: '#f0f8ff',
                        padding: '4px 8px',
                        borderRadius: '4px',
                        display: 'inline-block',
                        marginRight: '8px'
                      }}>
                        🎯 {record.focusItemName}
                      </div>
                    )}
                    {record.tagName && (
                      <div style={{
                        fontSize: '13px',
                        color: 'white',
                        fontWeight: '600',
                        marginBottom: '4px',
                        backgroundColor: record.tagColor || '#666666',
                        padding: '4px 8px',
                        borderRadius: '4px',
                        display: 'inline-block'
                      }}>
                        🏷️ {record.tagName}
                      </div>
                    )}
                    {record.description && (
                      <div style={{
                        fontSize: '13px',
                        color: '#888',
                        marginBottom: '6px',
                        fontStyle: 'italic'
                      }}>
                        {record.description}
                      </div>
                    )}
                    <div style={{
                      fontSize: '12px',
                      color: '#888',
                      display: 'flex',
                      gap: '16px'
                    }}>
                      <span>工作：{record.workMinutes} 分鐘</span>
                      <span>休息：{record.breakMinutes} 分鐘</span>
                    </div>
                  </div>
                  
                  {/* 編輯和刪除按鈕 */}
                  <div style={{
                    display: 'flex',
                    gap: '8px',
                    alignItems: 'center'
                  }}>
                    <button
                      onClick={() => handleEditRecord(record)}
                      style={{
                        padding: '6px 12px',
                        backgroundColor: '#ffc107',
                        color: 'white',
                        border: 'none',
                        borderRadius: '6px',
                        fontSize: '12px',
                        fontWeight: '600',
                        cursor: 'pointer',
                        transition: 'background-color 0.2s',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '4px'
                      }}
                      onMouseOver={(e) => {
                        e.currentTarget.style.backgroundColor = '#e0a800'
                      }}
                      onMouseOut={(e) => {
                        e.currentTarget.style.backgroundColor = '#ffc107'
                      }}
                    >
                      🖊 編輯
                    </button>
                    <button
                      onClick={() => handleDeleteRecord(record.id)}
                      style={{
                        padding: '6px 12px',
                        backgroundColor: '#dc3545',
                        color: 'white',
                        border: 'none',
                        borderRadius: '6px',
                        fontSize: '12px',
                        fontWeight: '600',
                        cursor: 'pointer',
                        transition: 'background-color 0.2s',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '4px'
                      }}
                      onMouseOver={(e) => {
                        e.currentTarget.style.backgroundColor = '#c82333'
                      }}
                      onMouseOut={(e) => {
                        e.currentTarget.style.backgroundColor = '#dc3545'
                      }}
                    >
                      🗑 刪除
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
            </>
          )
        })()}
      </div>

      {/* 專注項目管理模態框 */}
      {showFocusItemModal && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          zIndex: 1000
        }}>
          <div style={{
            backgroundColor: 'white',
            padding: '30px',
            borderRadius: '12px',
            width: '90%',
            maxWidth: '500px',
            maxHeight: '80vh',
            overflow: 'auto'
          }}>
            <h3 style={{ 
              margin: '0 0 20px 0', 
              color: '#333',
              fontSize: '1.4rem',
              fontWeight: '600'
            }}>
              🎯 專注項目管理
            </h3>

            {/* 新增專注項目 */}
            <div style={{ marginBottom: '30px' }}>
              <h4 style={{ 
                margin: '0 0 15px 0', 
                color: '#555',
                fontSize: '1.1rem'
              }}>
                新增專注項目
              </h4>
              <div style={{ display: 'flex', gap: '10px' }}>
                <input
                  type="text"
                  placeholder="輸入專注項目名稱..."
                  value={newFocusItemName}
                  onChange={(e) => setNewFocusItemName(e.target.value)}
                  style={{
                    flex: 1,
                    height: '48px',
                    padding: '12px 16px',
                    fontSize: '16px',
                    border: '2px solid #e0e0e0',
                    borderRadius: '8px',
                    outline: 'none',
                    transition: 'border-color 0.2s',
                    backgroundColor: '#ffffff',
                    color: '#333333',
                    fontWeight: '500',
                    minHeight: '48px',
                    width: '100%',
                    boxSizing: 'border-box',
                    zIndex: 1,
                    position: 'relative'
                  }}
                  onFocus={(e) => {
                    e.target.style.borderColor = '#4ecdc4'
                  }}
                  onBlur={(e) => {
                    e.target.style.borderColor = '#e0e0e0'
                  }}
                  onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                      handleAddFocusItem()
                    }
                  }}
                />
                <button
                  onClick={handleAddFocusItem}
                  disabled={!newFocusItemName.trim()}
                  style={{
                    padding: '8px 16px',
                    backgroundColor: newFocusItemName.trim() ? '#4ecdc4' : '#ccc',
                    color: 'white',
                    border: 'none',
                    borderRadius: '6px',
                    fontSize: '14px',
                    fontWeight: '600',
                    cursor: newFocusItemName.trim() ? 'pointer' : 'not-allowed',
                    transition: 'all 0.2s',
                    height: '48px',
                    minWidth: '60px',
                    minHeight: '48px',
                    zIndex: 1,
                    position: 'relative'
                  }}
                >
                  新增
                </button>
              </div>
            </div>

            {/* 專注項目列表 */}
            <div>
              <h4 style={{ 
                margin: '0 0 15px 0', 
                color: '#555',
                fontSize: '1.1rem'
              }}>
                專注項目列表
              </h4>
              <div style={{ maxHeight: '300px', overflow: 'auto' }}>
                {focusItems.map((item) => (
                  <div
                    key={item.id}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      padding: '12px 16px',
                      marginBottom: '8px',
                      backgroundColor: '#f8f9fa',
                      borderRadius: '8px',
                      border: '1px solid #e0e0e0'
                    }}
                  >
                    <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: '12px' }}>
                      <div 
                        className="color-dot"
                        style={{
                          width: '18px',
                          height: '18px',
                          borderRadius: '50%',
                          backgroundColor: item.color || '#4caf50',
                          border: '2px solid #ffffff',
                          boxShadow: '0 2px 4px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.3)',
                          flexShrink: 0,
                          filter: 'brightness(1.5) saturate(1.2)',
                          minWidth: '18px',
                          minHeight: '18px',
                          display: 'inline-block',
                          verticalAlign: 'middle'
                        }} 
                      />
                      <div>
                        <div 
                          className="focus-item-name"
                          style={{
                            fontSize: '18px',
                            fontWeight: '700',
                            color: '#333',
                            marginBottom: '4px'
                          }}
                        >
                          {item.name}
                          {item.isDefault && (
                            <span 
                              className="default-tag"
                              style={{
                                fontSize: '12px',
                                color: '#666',
                                marginLeft: '8px',
                                backgroundColor: '#e9ecef',
                                padding: '2px 6px',
                                borderRadius: '4px',
                                fontWeight: '600'
                              }}
                            >
                              預設
                            </span>
                          )}
                        </div>
                        <div 
                          className="focus-item-usage"
                          style={{
                            fontSize: '16px',
                            color: '#666',
                            fontWeight: '500'
                          }}
                        >
                          使用 {item.usageCount} 次
                        </div>
                      </div>
                    </div>
                    
                    <div style={{ display: 'flex', gap: '8px' }}>
                      {!item.isDefault && (
                        <>
                          <button
                            onClick={() => handleEditFocusItem(item)}
                            style={{
                              padding: '6px 12px',
                              backgroundColor: '#ffc107',
                              color: 'white',
                              border: 'none',
                              borderRadius: '6px',
                              fontSize: '12px',
                              cursor: 'pointer',
                              transition: 'background-color 0.2s'
                            }}
                            onMouseOver={(e) => {
                              e.currentTarget.style.backgroundColor = '#e0a800'
                            }}
                            onMouseOut={(e) => {
                              e.currentTarget.style.backgroundColor = '#ffc107'
                            }}
                          >
                            編輯
                          </button>
                          <button
                            onClick={() => handleDeleteFocusItem(item.id)}
                            style={{
                              padding: '6px 12px',
                              backgroundColor: '#dc3545',
                              color: 'white',
                              border: 'none',
                              borderRadius: '6px',
                              fontSize: '12px',
                              cursor: 'pointer',
                              transition: 'background-color 0.2s'
                            }}
                            onMouseOver={(e) => {
                              e.currentTarget.style.backgroundColor = '#c82333'
                            }}
                            onMouseOut={(e) => {
                              e.currentTarget.style.backgroundColor = '#dc3545'
                            }}
                          >
                            刪除
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 關閉按鈕 */}
            <div style={{
              display: 'flex',
              justifyContent: 'flex-end',
              marginTop: '20px'
            }}>
              <button
                onClick={() => {
                  setShowFocusItemModal(false)
                  setNewFocusItemName('')
                  setEditingFocusItem(null)
                  setEditingFocusItemName('')
                }}
                style={{
                  padding: '12px 24px',
                  backgroundColor: '#6c757d',
                  color: 'white',
                  border: 'none',
                  borderRadius: '8px',
                  fontSize: '14px',
                  fontWeight: '600',
                  cursor: 'pointer',
                  transition: 'background-color 0.2s'
                }}
                onMouseOver={(e) => {
                  e.currentTarget.style.backgroundColor = '#5a6268'
                }}
                onMouseOut={(e) => {
                  e.currentTarget.style.backgroundColor = '#6c757d'
                }}
              >
                關閉
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 編輯專注項目模態框 */}
      {editingFocusItem && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          zIndex: 1001
        }}>
          <div style={{
            backgroundColor: 'white',
            padding: '30px',
            borderRadius: '12px',
            width: '90%',
            maxWidth: '400px'
          }}>
            <h3 style={{ 
              margin: '0 0 20px 0', 
              color: '#333',
              fontSize: '1.3rem',
              fontWeight: '600'
            }}>
              編輯專注項目
            </h3>
            
            <div style={{ marginBottom: '20px' }}>
              <input
                type="text"
                value={editingFocusItemName}
                onChange={(e) => setEditingFocusItemName(e.target.value)}
                style={{
                  width: '100%',
                  padding: '12px 16px',
                  fontSize: '16px',
                  border: '2px solid #e0e0e0',
                  borderRadius: '8px',
                  outline: 'none',
                  transition: 'border-color 0.2s'
                }}
                onFocus={(e) => {
                  e.target.style.borderColor = '#4ecdc4'
                }}
                onBlur={(e) => {
                  e.target.style.borderColor = '#e0e0e0'
                }}
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    handleUpdateFocusItem()
                  }
                }}
              />
            </div>

            <div style={{
              display: 'flex',
              gap: '10px',
              justifyContent: 'flex-end'
            }}>
              <button
                onClick={() => {
                  setEditingFocusItem(null)
                  setEditingFocusItemName('')
                }}
                style={{
                  padding: '10px 20px',
                  backgroundColor: '#6c757d',
                  color: 'white',
                  border: 'none',
                  borderRadius: '8px',
                  fontSize: '14px',
                  fontWeight: '600',
                  cursor: 'pointer',
                  transition: 'background-color 0.2s'
                }}
                onMouseOver={(e) => {
                  e.currentTarget.style.backgroundColor = '#5a6268'
                }}
                onMouseOut={(e) => {
                  e.currentTarget.style.backgroundColor = '#6c757d'
                }}
              >
                取消
              </button>
              <button
                onClick={handleUpdateFocusItem}
                disabled={!editingFocusItemName.trim()}
                style={{
                  padding: '10px 20px',
                  backgroundColor: editingFocusItemName.trim() ? '#4ecdc4' : '#ccc',
                  color: 'white',
                  border: 'none',
                  borderRadius: '8px',
                  fontSize: '14px',
                  fontWeight: '600',
                  cursor: editingFocusItemName.trim() ? 'pointer' : 'not-allowed',
                  transition: 'background-color 0.2s'
                }}
              >
                儲存
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 編輯記錄模態框 */}
      {editingRecord && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          zIndex: 1002
        }}>
          <div style={{
            backgroundColor: 'white',
            padding: '30px',
            borderRadius: '12px',
            width: '90%',
            maxWidth: '500px'
          }}>
            <h3 style={{ 
              margin: '0 0 20px 0', 
              color: '#333',
              fontSize: '1.3rem',
              fontWeight: '600'
            }}>
              ✏️ 編輯記錄
            </h3>
            
            {/* 專注項目選擇 */}
            <div style={{ marginBottom: '20px' }}>
              <label style={{
                display: 'block',
                fontSize: '14px',
                color: '#666',
                marginBottom: '8px',
                fontWeight: '500'
              }}>
                專注項目
              </label>
              <select
                value={editingRecordFocusItemId}
                onChange={(e) => setEditingRecordFocusItemId(e.target.value)}
                style={{
                  width: '100%',
                  padding: '12px 16px',
                  fontSize: '16px',
                  border: '2px solid #e0e0e0',
                  borderRadius: '8px',
                  backgroundColor: '#fff',
                  color: '#333',
                  outline: 'none',
                  transition: 'border-color 0.2s'
                }}
                onFocus={(e) => {
                  e.target.style.borderColor = '#4ecdc4'
                }}
                onBlur={(e) => {
                  e.target.style.borderColor = '#e0e0e0'
                }}
              >
                {focusItems.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.name}
                  </option>
                ))}
              </select>
            </div>

            {/* 完成時間選擇 */}
            <div style={{ marginBottom: '20px' }}>
              <label style={{
                display: 'block',
                fontSize: '14px',
                color: '#666',
                marginBottom: '8px',
                fontWeight: '500'
              }}>
                完成時間
              </label>
              <input
                type="date"
                value={editingRecordCompletedAt}
                onChange={(e) => setEditingRecordCompletedAt(e.target.value)}
                style={{
                  width: '100%',
                  padding: '12px 16px',
                  fontSize: '16px',
                  border: '2px solid #e0e0e0',
                  borderRadius: '8px',
                  backgroundColor: '#fff',
                  color: '#333',
                  outline: 'none',
                  transition: 'border-color 0.2s'
                }}
                onFocus={(e) => {
                  e.target.style.borderColor = '#4ecdc4'
                }}
                onBlur={(e) => {
                  e.target.style.borderColor = '#e0e0e0'
                }}
              />
            </div>

            {/* 按鈕區域 */}
            <div style={{
              display: 'flex',
              gap: '10px',
              justifyContent: 'flex-end'
            }}>
              <button
                onClick={() => {
                  setEditingRecord(null)
                  setEditingRecordFocusItemId('')
                  setEditingRecordCompletedAt('')
                }}
                style={{
                  padding: '12px 24px',
                  backgroundColor: '#6c757d',
                  color: 'white',
                  border: 'none',
                  borderRadius: '8px',
                  fontSize: '14px',
                  fontWeight: '600',
                  cursor: 'pointer',
                  transition: 'background-color 0.2s'
                }}
                onMouseOver={(e) => {
                  e.currentTarget.style.backgroundColor = '#5a6268'
                }}
                onMouseOut={(e) => {
                  e.currentTarget.style.backgroundColor = '#6c757d'
                }}
              >
                取消
              </button>
              <button
                onClick={handleUpdateRecord}
                disabled={!editingRecordFocusItemId || !editingRecordCompletedAt}
                style={{
                  padding: '12px 24px',
                  backgroundColor: (editingRecordFocusItemId && editingRecordCompletedAt) ? '#4ecdc4' : '#ccc',
                  color: 'white',
                  border: 'none',
                  borderRadius: '8px',
                  fontSize: '14px',
                  fontWeight: '600',
                  cursor: (editingRecordFocusItemId && editingRecordCompletedAt) ? 'pointer' : 'not-allowed',
                  transition: 'background-color 0.2s'
                }}
              >
                儲存
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 標籤管理模態框 */}
      {showTagModal && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          zIndex: 1003
        }}>
          <div style={{
            backgroundColor: 'white',
            padding: '30px',
            borderRadius: '12px',
            width: '90%',
            maxWidth: '600px',
            maxHeight: '80vh',
            overflow: 'auto'
          }}>
            <h3 style={{ 
              margin: '0 0 20px 0', 
              color: '#333',
              fontSize: '1.4rem',
              fontWeight: '600'
            }}>
              🏷️ 標籤管理
            </h3>

            {/* 新增標籤 */}
            <div style={{ marginBottom: '30px' }}>
              <h4 style={{ 
                margin: '0 0 15px 0', 
                color: '#555',
                fontSize: '1.1rem'
              }}>
                新增標籤
              </h4>
              <div style={{ display: 'flex', gap: '10px', alignItems: 'center', flexWrap: 'wrap' }}>
                <input
                  type="text"
                  placeholder="輸入標籤名稱..."
                  value={newTagName}
                  onChange={(e) => setNewTagName(e.target.value)}
                  style={{
                    flex: 1,
                    minWidth: '200px',
                    padding: '12px 16px',
                    fontSize: '16px',
                    border: '2px solid #e0e0e0',
                    borderRadius: '8px',
                    outline: 'none',
                    transition: 'border-color 0.2s'
                  }}
                  onFocus={(e) => {
                    e.target.style.borderColor = '#2196f3'
                  }}
                  onBlur={(e) => {
                    e.target.style.borderColor = '#e0e0e0'
                  }}
                />
                <input
                  type="color"
                  value={newTagColor}
                  onChange={(e) => setNewTagColor(e.target.value)}
                  style={{
                    width: '50px',
                    height: '50px',
                    border: 'none',
                    borderRadius: '8px',
                    cursor: 'pointer'
                  }}
                />
                <button
                  onClick={() => {
                    if (newTagName.trim()) {
                      addTaskTag(newTagName.trim(), newTagColor)
                      const updatedTags = getTaskTagsWithCount()
                      setTaskTags(updatedTags)
                      setNewTagName('')
                      setNewTagColor(getRandomTagColor())
                    }
                  }}
                  disabled={!newTagName.trim()}
                  style={{
                    padding: '12px 20px',
                    backgroundColor: newTagName.trim() ? '#2196f3' : '#ccc',
                    color: 'white',
                    border: 'none',
                    borderRadius: '8px',
                    fontSize: '14px',
                    fontWeight: '600',
                    cursor: newTagName.trim() ? 'pointer' : 'not-allowed',
                    transition: 'background-color 0.2s'
                  }}
                >
                  新增
                </button>
              </div>
            </div>

            {/* 標籤列表 */}
            <div>
              <h4 style={{ 
                margin: '0 0 15px 0', 
                color: '#555',
                fontSize: '1.1rem'
              }}>
                標籤列表
              </h4>
              <div style={{ maxHeight: '300px', overflow: 'auto' }}>
                {taskTags.map((tag) => (
                  <div
                    key={tag.id}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      padding: '12px 16px',
                      marginBottom: '8px',
                      backgroundColor: '#f8f9fa',
                      borderRadius: '8px',
                      border: '1px solid #e0e0e0'
                    }}
                  >
                    <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: '12px' }}>
                      <div 
                        className="color-dot"
                        style={{
                          width: '20px',
                          height: '20px',
                          borderRadius: '50%',
                          backgroundColor: tag.color,
                          border: '2px solid #ffffff',
                          boxShadow: '0 2px 4px rgba(0, 0, 0, 0.3)'
                        }} 
                      />
                      <div>
                        <div style={{
                          fontSize: '16px',
                          fontWeight: '600',
                          color: '#333',
                          marginBottom: '4px'
                        }}>
                          {tag.name}
                          {tag.isDefault && (
                            <span style={{
                              fontSize: '12px',
                              color: '#666',
                              marginLeft: '8px',
                              backgroundColor: '#e9ecef',
                              padding: '2px 6px',
                              borderRadius: '4px'
                            }}>
                              預設
                            </span>
                          )}
                        </div>
                        <div style={{
                          fontSize: '14px',
                          color: '#666'
                        }}>
                          使用 {tag.usageCount} 次
                        </div>
                      </div>
                    </div>
                    
                    <div style={{ display: 'flex', gap: '8px' }}>
                      {!tag.isDefault && (
                        <>
                          <button
                            onClick={() => {
                              setEditingTag(tag)
                              setEditingTagName(tag.name)
                              setEditingTagColor(tag.color)
                            }}
                            style={{
                              padding: '6px 12px',
                              backgroundColor: '#ffc107',
                              color: 'white',
                              border: 'none',
                              borderRadius: '6px',
                              fontSize: '12px',
                              cursor: 'pointer',
                              transition: 'background-color 0.2s'
                            }}
                            onMouseOver={(e) => {
                              e.currentTarget.style.backgroundColor = '#e0a800'
                            }}
                            onMouseOut={(e) => {
                              e.currentTarget.style.backgroundColor = '#ffc107'
                            }}
                          >
                            編輯
                          </button>
                          <button
                            onClick={() => {
                              if (window.confirm('確定要刪除這個標籤嗎？')) {
                                const success = deleteTaskTag(tag.id)
                                if (success) {
                                  const updatedTags = getTaskTagsWithCount()
                                  setTaskTags(updatedTags)
                                  // 如果刪除的是當前選中的標籤，選擇第一個標籤
                                  if (selectedTagId === tag.id && updatedTags.length > 0) {
                                    setSelectedTagId(updatedTags[0].id)
                                  }
                                }
                              }
                            }}
                            style={{
                              padding: '6px 12px',
                              backgroundColor: '#dc3545',
                              color: 'white',
                              border: 'none',
                              borderRadius: '6px',
                              fontSize: '12px',
                              cursor: 'pointer',
                              transition: 'background-color 0.2s'
                            }}
                            onMouseOver={(e) => {
                              e.currentTarget.style.backgroundColor = '#c82333'
                            }}
                            onMouseOut={(e) => {
                              e.currentTarget.style.backgroundColor = '#dc3545'
                            }}
                          >
                            刪除
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 關閉按鈕 */}
            <div style={{
              display: 'flex',
              justifyContent: 'flex-end',
              marginTop: '20px'
            }}>
              <button
                onClick={() => {
                  setShowTagModal(false)
                  setNewTagName('')
                  setNewTagColor(getRandomTagColor())
                  setEditingTag(null)
                  setEditingTagName('')
                  setEditingTagColor('#2196f3')
                }}
                style={{
                  padding: '12px 24px',
                  backgroundColor: '#6c757d',
                  color: 'white',
                  border: 'none',
                  borderRadius: '8px',
                  fontSize: '14px',
                  fontWeight: '600',
                  cursor: 'pointer',
                  transition: 'background-color 0.2s'
                }}
                onMouseOver={(e) => {
                  e.currentTarget.style.backgroundColor = '#5a6268'
                }}
                onMouseOut={(e) => {
                  e.currentTarget.style.backgroundColor = '#6c757d'
                }}
              >
                關閉
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 編輯標籤模態框 */}
      {editingTag && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          zIndex: 1004
        }}>
          <div style={{
            backgroundColor: 'white',
            padding: '30px',
            borderRadius: '12px',
            width: '90%',
            maxWidth: '400px'
          }}>
            <h3 style={{ 
              margin: '0 0 20px 0', 
              color: '#333',
              fontSize: '1.3rem',
              fontWeight: '600'
            }}>
              編輯標籤
            </h3>
            
            <div style={{ marginBottom: '20px' }}>
              <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                <input
                  type="text"
                  value={editingTagName}
                  onChange={(e) => setEditingTagName(e.target.value)}
                  style={{
                    flex: 1,
                    padding: '12px 16px',
                    fontSize: '16px',
                    border: '2px solid #e0e0e0',
                    borderRadius: '8px',
                    outline: 'none',
                    transition: 'border-color 0.2s'
                  }}
                  onFocus={(e) => {
                    e.target.style.borderColor = '#2196f3'
                  }}
                  onBlur={(e) => {
                    e.target.style.borderColor = '#e0e0e0'
                  }}
                />
                <input
                  type="color"
                  value={editingTagColor}
                  onChange={(e) => setEditingTagColor(e.target.value)}
                  style={{
                    width: '50px',
                    height: '50px',
                    border: 'none',
                    borderRadius: '8px',
                    cursor: 'pointer'
                  }}
                />
              </div>
            </div>

            <div style={{
              display: 'flex',
              gap: '10px',
              justifyContent: 'flex-end'
            }}>
              <button
                onClick={() => {
                  setEditingTag(null)
                  setEditingTagName('')
                  setEditingTagColor('#2196f3')
                }}
                style={{
                  padding: '10px 20px',
                  backgroundColor: '#6c757d',
                  color: 'white',
                  border: 'none',
                  borderRadius: '8px',
                  fontSize: '14px',
                  fontWeight: '600',
                  cursor: 'pointer',
                  transition: 'background-color 0.2s'
                }}
                onMouseOver={(e) => {
                  e.currentTarget.style.backgroundColor = '#5a6268'
                }}
                onMouseOut={(e) => {
                  e.currentTarget.style.backgroundColor = '#6c757d'
                }}
              >
                取消
              </button>
              <button
                onClick={() => {
                  if (editingTag && editingTagName.trim()) {
                    const success = updateTaskTag(editingTag.id, editingTagName.trim(), editingTagColor)
                    if (success) {
                      const updatedTags = getTaskTagsWithCount()
                      setTaskTags(updatedTags)
                      setEditingTag(null)
                      setEditingTagName('')
                      setEditingTagColor('#2196f3')
                    }
                  }
                }}
                disabled={!editingTagName.trim()}
                style={{
                  padding: '10px 20px',
                  backgroundColor: editingTagName.trim() ? '#2196f3' : '#ccc',
                  color: 'white',
                  border: 'none',
                  borderRadius: '8px',
                  fontSize: '14px',
                  fontWeight: '600',
                  cursor: editingTagName.trim() ? 'pointer' : 'not-allowed',
                  transition: 'background-color 0.2s'
                }}
              >
                儲存
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default PomodoroPage
